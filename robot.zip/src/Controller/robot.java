package Controller;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.google.gson.Gson;
@WebServlet("/Controller")
public class robot extends HttpServlet{
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
			request.setCharacterEncoding("utf-8");
			response.setContentType("text/html;charset=utf-8");
			Map<String,Object> map=new HashMap<String, Object>();
			String input=request.getParameter("input");
			String info = URLEncoder.encode(input, "utf-8");
			String APIkey = "9257afd24a374c69b91eeb687d463763";
			String get = "http://www.tuling123.com/openapi/api?key="
							+APIkey+"&info="+info;
			URL url = new URL(get);
			HttpURLConnection con = (HttpURLConnection) url.openConnection();
			con.connect();
			InputStream i = con.getInputStream();
			InputStreamReader is = new InputStreamReader(i, "utf-8");
			StringBuffer sb = new StringBuffer();
			String answer = sb.substring(sb.lastIndexOf(":")+2,sb.indexOf("}")-1);
			map.put("answer", answer);
			String Str=new Gson().toJson(map);
			PrintWriter n=response.getWriter();
			n.printf(Str);	
			n.flush();
			n.close();
	}
}
